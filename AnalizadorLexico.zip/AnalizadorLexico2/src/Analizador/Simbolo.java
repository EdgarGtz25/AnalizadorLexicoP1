/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Analizador;

/**
 *
 * @author Edgar Gutierrez
 */
public class Simbolo {
    //LOS SIMBOLOS TIENEN UN VALOR EN EL CUAL SERA COMO UN TIPO INDICE PARA VALIDARLOS EN NUESTRO ANALISIS LEXICO
    public static final int Error=1;
    public static final int PALRE=101;
    public static final int ID=102;
    public static final int Comentarios=103;
    public static final int OPLOG=104;
    public static final int OPARI=105;
    public static final int OPESP=106;
    public static final int OPIND=107;
    public static final int OPASI=108;
    public static final int OPREL=109; 
    public static final int NUM=110;
    public static final int Saltolinea=111;
    public static final int Tab=112;
    public static final int Espacio=113;
    public static final int Mensaje=114;
    public static final int ComentariosMul=115;



        

}
