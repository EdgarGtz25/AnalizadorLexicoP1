/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Analizador;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 *
 * @author Edgar Gutierrez
 */
public class Gest {
    FileInputStream entrada;
    FileOutputStream salida;
    File archivo;
    
       public String GuardarTexto(File archivo,String contenido){
        String respuesta=null;
        try {
            salida = new FileOutputStream(archivo);
            byte[] bytesTxt = contenido.getBytes();
            salida.write(bytesTxt);
            respuesta="Archivo guardado con exito";
            
        } catch (Exception e) {
        }
        return respuesta;
    }
  


}
