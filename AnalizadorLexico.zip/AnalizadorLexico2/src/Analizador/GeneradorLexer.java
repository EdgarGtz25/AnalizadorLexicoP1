/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Analizador;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author Edgar Gutierrez
 */
public class GeneradorLexer {
    
    public static void main(String args[]) throws IOException{
        JFlex.Main.generate(new File("C:/Users/tuesp/OneDrive/Documentos/NetBeansProjects/AnalizadorLexico2/src/Analizador/lexer.flex"));
    }
}
